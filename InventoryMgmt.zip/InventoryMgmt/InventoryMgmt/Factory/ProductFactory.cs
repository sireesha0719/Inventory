﻿using InventoryMgmt.Products;
using System;
using System.Collections.Generic;
using System.Text;

namespace InventoryMgmt.Factory
{
    public class ProductFactory
    {
        public static Product GetProduct(ProductType prodType, int sellIn, uint quality)
        {
            switch (prodType)
            {
                case ProductType.AgedBrie:
                    return new AgedBrie(prodType, sellIn, quality);
                case ProductType.ChristmasCrackers:
                    return new ChristmasCrakers(prodType, sellIn, quality);
                case ProductType.FreshItem:
                    return new FreshFood(prodType, sellIn, quality);
                case ProductType.FrozenItem:
                    return new FrozenFood(prodType, sellIn, quality);
                case ProductType.Soap:
                    return new Soap(prodType, sellIn, quality);
                default:
                    return null;
            }
        }

    }
}
