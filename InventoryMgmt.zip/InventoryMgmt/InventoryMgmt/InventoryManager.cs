﻿using InventoryMgmt.Factory;
using InventoryMgmt.Products;
using System;
using System.Collections.Generic;
using System.Text;

namespace InventoryMgmt
{
    class InventoryManager
    {
        public DateTime LastRunDate { get; set; }
        static InventoryManager inventoryManager = new InventoryManager();
        public static InventoryManager Instance => inventoryManager;

        List<Product> _products = new List<Product>();

        private InventoryManager()
        {

        }

        public IReadOnlyList<Product> Products => _products;

        public void AddToInventory(string Name, int sellIn, uint quality)
        {
            var prodType = StringToProductType(Name);
            Product product = ProductFactory.GetProduct(prodType, sellIn, quality);

            if (product == null)
            {
                Console.WriteLine("NO SUCH ITEM..!!");
                return;
            }

            _products.Add(product);
        }

        public void RunInventory()
        {
            foreach (var product in _products)
            {
                product.UpdateInventory();
                Console.WriteLine(product);
            }
        }

        private ProductType StringToProductType(string prodName)
        {
            switch (prodName.ToLower())
            {
                case "aged brie":
                    return ProductType.AgedBrie;
                case "christmas crackers":
                    return ProductType.ChristmasCrackers;
                case "soap":
                    return ProductType.Soap;
                case "frozen item":
                    return ProductType.FrozenItem;
                case "fresh item":
                    return ProductType.FreshItem;
                default:
                    return ProductType.Invalid;
            }
        }
    }
}
