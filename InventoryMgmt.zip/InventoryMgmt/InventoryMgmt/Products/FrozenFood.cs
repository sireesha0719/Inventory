﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InventoryMgmt.Products
{
    public sealed class FrozenFood : Product
    {
        public FrozenFood(ProductType type, int sellIn, uint quantity)
            : base(type, sellIn, quantity)
        {

        }

        public override void UpdateInventory()
        {
            SellIn--;

            if (SellIn >= 0)
            {
                if ((Quality - 1) >= 0)
                {
                    Quality--;
                }
                else
                {
                    Quality = 0;
                }
            }
            else
            {
                if ((Quality - 5) >= 0)
                {
                    Quality -= 5;
                }
                else
                    Quality = 0;
            }
        }
    }
}
