﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InventoryMgmt.Products
{
    public sealed class AgedBrie : Product
    {

        public AgedBrie(ProductType type, int sellIn, uint quatity)
            : base(type, sellIn, quatity)
        {

        }

        public override void UpdateInventory()
        {
            SellIn--;
            if ((Quality + 1) <= 50)
                Quality++;
        }
    }
}
