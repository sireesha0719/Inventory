﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InventoryMgmt.Products
{
    public abstract class Product
    {
        public ProductType ProductType { get; set; }
        public int SellIn { get; set; }
        public uint Quality { get; set; }

        public Product(ProductType productType, int sellIn, uint quatity)
        {
            ProductType = productType;
            SellIn = sellIn;
            Quality = quatity;
        }

        public virtual void UpdateInventory()
        {
            SellIn--;
            if (SellIn >= 0)
            {
                Quality--;
            }
            else
            {
                if ((Quality - 2) >= 0)
                    Quality -= 2;
            }
        }

        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.Append(EnumToString());
            sb.Append(" ");
            sb.Append(SellIn);
            sb.Append(" ");
            sb.Append(Quality);
            return sb.ToString();
        }

        protected string EnumToString()
        {
            switch (ProductType)
            {
                case ProductType.AgedBrie:
                    return "Aged Brie";
                case ProductType.ChristmasCrackers:
                    return "Christmas Crackers";
                case ProductType.FreshItem:
                    return "Fresh Item";
                case ProductType.FrozenItem:
                    return "Frozen Item";
                case ProductType.Soap:
                    return "Soap";
                case ProductType.Invalid:
                default:
                    return "NO SUCH ITEM";
            }
        }
    }
}
