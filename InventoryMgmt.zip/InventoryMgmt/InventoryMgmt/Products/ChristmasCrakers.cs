﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InventoryMgmt.Products
{
    public sealed class ChristmasCrakers : Product
    {
        public ChristmasCrakers(ProductType type, int sellIn, uint quantity)
            : base(type, sellIn, quantity)
        {

        }

        public override void UpdateInventory()
        {
            SellIn--;

            if (SellIn < 0)
            {
                Quality = 0;
                return;
            }

            if (SellIn > 10)
            {
                Quality++;
            }
            else if (SellIn <= 10 && SellIn > 5)
            {
                if ((Quality + 2) <= 50)
                    Quality += 2;
            }
            else if (SellIn <= 5)
            {
                if ((Quality + 3) <= 50)
                    Quality += 3;
            }
        }
    }
}
