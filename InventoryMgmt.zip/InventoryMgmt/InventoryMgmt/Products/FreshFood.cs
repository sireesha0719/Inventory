﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InventoryMgmt.Products
{
    public sealed class FreshFood : Product
    {
        public FreshFood(ProductType type, int sellIn, uint quantity)
            : base(type, sellIn, quantity)
        {

        }

        public override void UpdateInventory()
        {
            SellIn--;

            if (SellIn >= 0)
            {
                if ((Quality - 2) >= 0)
                {
                    Quality -= 2;
                }
                else
                {
                    Quality = 0;
                }
            }
            else
            {
                if ((Quality - 4) >= 0)
                {
                    Quality -= 4;
                }
                else
                    Quality = 0;
            }
        }
    }
}
