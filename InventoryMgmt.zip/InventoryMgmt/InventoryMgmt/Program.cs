﻿using System;

namespace InventoryMgmt
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Store Inventory!!");

            Console.WriteLine("Add items to inventory in the following format:<<ProductName>> <<SellIn>> <<Quality>>");

            while (true)
            {
                var command = Console.ReadLine();
                if (command.ToLower() == "run" || (DateTime.Now - InventoryManager.Instance.LastRunDate).TotalDays > 0)
                {
                    InventoryManager.Instance.RunInventory();
                    InventoryManager.Instance.LastRunDate = DateTime.Now;
                }
                else if (command == "exit")
                {
                    //Does nothing. Control by itself exit from running.
                }
                else
                {
                    string productName;
                    int sellIn;
                    uint quality;
                    var productDetails = command.Split(' ');

                    if (productDetails.Length > 3)
                    {
                        productName = productDetails[0] + " " + productDetails[1];
                        sellIn = Convert.ToInt32(productDetails[2]);
                        quality = Convert.ToUInt32(productDetails[3]);
                    }
                    else
                    {
                        productName = productDetails[0];
                        sellIn = Convert.ToInt32(productDetails[1]);
                        quality = Convert.ToUInt32(productDetails[2]);
                    }

                    InventoryManager.Instance.AddToInventory(productName, sellIn, quality);
                }
            }
        }
    }

    public enum ProductType
    {
        Invalid,
        AgedBrie,
        ChristmasCrackers,
        Soap,
        FrozenItem,
        FreshItem,
    }
}
