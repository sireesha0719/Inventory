﻿using InventoryMgmt.Products;
using System;
using System.Collections.Generic;
using System.Text;

namespace InventoryMgmt
{
    public sealed class Soap : Product
    {
        public Soap(ProductType type, int sellIn, uint quantity)
            : base(type, sellIn, quantity)
        {

        }

        public override void UpdateInventory()
        {
            // Soap does not degrade.
        }
    }
}
